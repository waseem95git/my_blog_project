from django.conf.urls import url
from django.contrib import admin
from blog import views as v

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', v.post_list_view,name='home'),
    #back slash -w it means any alpha numeric charaters,and + any no of times
    url(r'^tag/(?P<tag_slug>[-\w]+)/$', v.post_list_view,name='post_list_by_tag_name'),
    #url(r'^$', v.PostListView.as_view()),
    url(r'^(?P<year>\d{4})/(?P<month>\d{2})/(?P<day>\d{2})/(?P<post>[-\w]+)/$',
         v.post_detail_view,name='post_detail'),
    url(r'^(?P<id>\d+)/share/$',v.mail_send_view ),
    url('create/', v.PostCreateView.as_view(),name='create'),
    url(r'^(?P<id>\d+)/update/$', v.PostUpdateView.as_view(),name='post_update'),

]











