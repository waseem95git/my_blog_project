from django.shortcuts import render, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import ListView
from django.core.mail import send_mail
from taggit.models import Tag
from .models import Post
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from .forms import EmailSendForm
from .forms import CommentForm,Comment
from django.views.generic import CreateView,ListView,DeleteView,DetailView,UpdateView

# Create your views here.
def post_list_view(request,tag_slug=None):
    post_list=Post.objects.all()
    #Tags are using here
    tag=None
    if tag_slug:
        tag=get_object_or_404(Tag,slug=tag_slug)
        post_list=post_list.filter(tags__in=[tag])

#"""************Pagination start from here******"""
    paginator=Paginator(post_list,2) # this 2 indicate how much post you want in per page
    page_number=request.GET.get('page')
    try:
        post_list=paginator.page(page_number)
    except PageNotAnInteger:
        post_list=paginator.page(1) # this 1 indicate home page
    except EmptyPage:
        post_list=paginator.page(paginator.num_pages)
        """****END Here***"""

    return render(request,'blog/post_list.html',{'post_list':post_list,'tag':tag})

"""
class PostListView(ListView):
    model = Post
    paginate_by = 2  # this is also indiactes how much post you want
"""
def post_detail_view(request,year,month,day,post):
    post=get_object_or_404(Post,slug=post,
                           status='published',
                           publish__year=year,
                           publish__month=month,
                           publish__day=day)

#*********For comment related thing here****
    comments=post.comments.filter(active=True)
    csubmit=False
    if request.method=='POST':
        form=CommentForm(request.POST)
        if form.is_valid():
            new_comment=form.save(commit=False)
            new_comment.post=post
            new_comment.save()
            csubmit=True
    else:
        form=CommentForm()
    return render(request,'blog/post_detail.html',{'post':post,'form':form,'csubmit':csubmit,'comments':comments})

# *******Mail Send*******
def mail_send_view(request,id):
    post=get_object_or_404(Post,id=id,status='published')
    sent=False
    if request.method=='POST':
        form=EmailSendForm(request.POST)
        if form.is_valid():
            cd=form.cleaned_data
            subject='{}({}) recommends you to read"{}"'.format(cd['name'],cd['email'],post.title)
            post_url=request.build_absolute_uri(post.get_absolute_url())
            message='Read post At:\n{}\n\n{}"s Comments:\n{}'.format(post_url ,cd['name'],cd['comments'])
            send_mail(subject,message,'python6656@gmail.com',[cd['to']])
            sent=True
    else:
        form=EmailSendForm()
    return render(request,'blog/sharebymail.html',{'form':form,'post':post,'sent':sent})

#***********Modification************

class PostCreateView(CreateView):
    model = Post
    fields = '__all__'
    template_name = 'blog/post_form.html'

#class PostListView(ListView):
#    model = Post


class PostUpdateView(UpdateView):
    model = Post
#    fields = '__all__'
    template_name = 'post_form.html'
    fields = ('author','slug')

    # def get_success_url(self):
    #     return reverse_lazy('post_update', kwargs={'pk': self.get_object().id})