"""
sending mail by pycharm console:===

from django.core.mail import send_mail
send_mail('hello....','very bad news','waseem',['waseemin95@gmail.com','jitendra.mhankuda@gmail.com'])
"""

"""
admin  id password
user1: waseem/waseem123
user2:faheem/waseem123@
user3:rahman/waseem123@
"""


from django.contrib import admin
from .models import Post,Comment

# Register your models here.

class PostAdmin(admin.ModelAdmin):
    list_display = ['title','slug','author','body','publish','created','updated','status']
    list_filter = ('status','author','created','publish')
    search_fields = ('title','body')
    raw_id_fields = ('author',)
    date_hierarchy = 'publish'
    ordering = ['status','publish']
    prepopulated_fields = {'slug':('title',)}

class CommentAdmin(admin.ModelAdmin):
    list_display = ('name','email','post','body','created','updated','active')
    list_filter = ('active','created','updated')
    search_fields = ('name','email','body')

admin.site.register(Post,PostAdmin)
admin.site.register(Comment,CommentAdmin)


